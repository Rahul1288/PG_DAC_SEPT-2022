

/*

1
2 3
4 5 6
7 8 9 10
11 12 13 14 15

*/


import java.util.*;

class PatternQ3
{
	public static void main(String args[])
	{
		int i, j, k=1;
		for( i=0; i<6; i++)
		{
			
			for( j=0; j<i; j++)
			{
				System.out.print(k++ +" ");
			}
			System.out.println();
		}
	}
}