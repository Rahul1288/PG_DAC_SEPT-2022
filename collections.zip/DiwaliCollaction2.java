/*2. Write a Java program to insert an element into the array list at the first position.
*/
import java.util.*;
class DiwaliCollaction2
{
	public static void main(String args[])
	{
		ArrayList<String> a = new ArrayList<String>();
		a.add("red");
		a.add("pink");
		a.add("black");
		a.add("yellow");
		a.add("white");
		a.add("marun");
		System.out.println("before adding element");
		System.out.println(a);
		a.set(0,"first");
		System.out.println("after adding element");
		System.out.println(a);
	}
}