/*1. Write a Java program to create a new array list, add some colors (string) and print out the 
collection.*/
import java.util.*;
class DiwaliCollaction1
{
	public static void main(String args[])
	{
		ArrayList<String> a = new ArrayList<String>();
		a.add("red");
		a.add("pink");
		a.add("black");
		a.add("yellow");
		a.add("white");
		a.add("marun");
		System.out.println(a);
		
	}
}