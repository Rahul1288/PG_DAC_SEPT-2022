/*3. Write a Java program to retrieve an element (at a specified index) from a given array list.*/
import java.util.*;
class DiwaliCollaction3
{
	public static void main(String args[])
	{
		ArrayList<String> a = new ArrayList<String>();
		a.add("red");
		a.add("pink");
		a.add("black");
		a.add("yellow");
		a.add("white");
		a.add("marun");
		System.out.println("before adding element");
		System.out.println(a);
		a.set(0,"first");
		System.out.println("after adding element");
		System.out.println(a);
		System.out.println("the element at index 2 is "+a.get(2));
	}
}