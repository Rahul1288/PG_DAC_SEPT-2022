//How to convert Array to TreeSet in java ?

import java.util.*;

class Q22
{
   public static void main(String[] args)
   {
      Integer[] arr = {5,98,45,4,1,87,2};
	  List<Integer> list = Arrays.asList(arr);
      Set<Integer> set = new TreeSet<Integer>(list);
      System.out.println("The set element are :");
	     for(Integer var : set)
		    System.out.println(var);
  	  
	  }
}