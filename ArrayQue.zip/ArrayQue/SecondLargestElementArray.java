// Write a program to find second largest element in a given Array in java?

import java.util.*;

 class SecondLargestElementArray
{
  static int getSecondLarge(int[]arr,int total)
	{
	    int temp;
		for(int i=0;i<total;i++)
		{
		   for(int j=i+1;j<total;j++)
		   {
			   if(arr[i]>arr[j])
			   {
		         temp = arr[i];
			     arr[i] = arr[j];
			     arr[j] = temp;
			   }
		    }	
	    }
	return arr[total-2];
}
public static void main(String[] args)
{
   int arr[] = {10,55,66,44,88,22,77,99,33};
   System.out.println("Display Second Largest Element :" +getSecondLarge(arr,9));
}
}