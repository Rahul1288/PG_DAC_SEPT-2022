//Write a Java program to check the equality of two arrays?

import java.util.Arrays;
class Q2{

    public static void main(String[] args)
	{
	     int arr1[] = {10,20,30};
		 int arr2[] = {10,20,30,};
		 boolean result = Arrays.equals(arr1,arr2);
		 
		    if(result == true)
			{
			     System.out.println("Arrays are equal");
			}
			else
			{
			     System.out.println("Arrays are not equal");
			}
	}
}