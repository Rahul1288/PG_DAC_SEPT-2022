//How do you separate zeros and non-zeros in a given Array in java?

import java.util.*;

class Q20
{
   public static void main(String[] args)
   {
       Scanner sc = new Scanner(System.in);
	   System.out.println("Enter the size if array : ");
	   int size = sc.nextInt();
	   int[] arr = new int[size];
	   System.out.println("Enter the element in the aaray :");
	      
		  for(int i=0;i<size;i++)
		  {
		     arr[i] = sc.nextInt();
			 
		  }
		  System.out.println("the array is :"+Arrays.toString(arr));
		  System.out.println("resultant array :");
		  
		  int temp=0;
		     for(int i=0;i<arr.length;i++)
			 {
			      if(arr[i] != 0)
				  {
				    arr[temp] = arr[i];
					temp++;
				  }
			 }
			
            while(temp<arr.length)
            {
			   arr[temp] = 0;
			   temp++;
			}
            System.out.println("The array is :"+Arrays.toString(arr));			
			
   }
}