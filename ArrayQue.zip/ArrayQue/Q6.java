 //Print the third-largest number in an array without sorting it
//: [ 24,54,31,16,82,45,67]

import java.util.*;
class Q6
{
   public static int getThirdLargest(int[]a,int total)
   
   {
      int temp;
	  for(int i=0;i<total;i++)
	  {
	     for(int j=i+1;j<total;j++)
		 {
		    if(a[i]>a[j])
			{
			   temp = a[i];
			   a[i] = a[j];
			   a[j] = temp;
			}   
		 }
       }  
    
	return a[total-3];
}
    public static void main(String[] args)
	{
	    int a[] ={2,5,11,33,7,99};
		System.out.println("Third largest :"+getThirdLargest(a,6));
	}
}

/*
OUTPUT:
Third largest :11
*/