//Write a program to reverse an Array in java .

import java.util.*;
class Q4{

    public static void main(String[] args)
    {
	   int arr[] = new int[]{1,3,5,7,9};
	   System.out.println("Print the array");
	      
		  for(int i=0;i<arr.length;i++)
		  {
		      System.out.print(arr[i]+ " ");
		  }
		  System.out.println();
		  System.out.println("=============================");
		  System.out.println("Reverse array");   
			 for(int j=arr.length-1;j>=0;j--)
			 {
			    
				System.out.print(arr[j]+" ");
			 }
    }	
}

/*
OUTPUT :
Print the array
1 3 5 7 9
=============================
Reverse array
9 7 5 3 1
*/